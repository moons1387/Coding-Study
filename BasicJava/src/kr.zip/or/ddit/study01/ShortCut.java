package kr.or.ddit.study01;

public class ShortCut {
	public static void main(String[] args) {
		
		// Crtl+Shift+L = 이클립스 모든 단축키 안내
		
		// Crtl+Shift+/ = 블록을 주석으로 처리
		
		// Crtl+Shift+\ = 블록을 주석 해제
		
		// Crtl+Shift+F = 자동 정렬
		
		// Crtl+Shift+C = 한줄 주석/해제
		
		// Alt+방향키(위 아래) = 줄 바꿈
		
		// Crtl+Alt+방향키(위 아래) = 복사
		
		// Crtl+D = 한줄 삭제
		
		// Crtl+Z = 실행 취소
		
		// Crtl+Y = 다시 실행
		
		// Crtl+F = 키워드 찾기
		
		// Crtl+H = 파일 서치
		
		// Alt+Shift+R = 변수 동시 변경
		
		// Crlt+Shift+X = 소문자 -> 대문자 변경
		
		// Crlt+Shift+Y = 대문자 -> 소문자 변경
		
		String test = "test";
		test = "test2";
		test = "test3";

		System.out.println("테스트1");
		System.out.println("테스트1");
		System.out.println("테스트2");
		System.out.println("테스트3");
		System.out.println("테스트4");
		System.out.println("테스트5");

	}

}
