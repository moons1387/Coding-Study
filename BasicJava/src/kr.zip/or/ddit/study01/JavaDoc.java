package kr.or.ddit.study01;

/**
 * 도큐먼트 주석
 * 외부에서 주석을 볼 수 있음
 *
 */
public class JavaDoc {
	public static void main(String[] args) {
		// syso Crtl + Spacebar
		System.out.println("테스트"); // 테스트

		// 한줄주석 "//" 부터 라인 끝까지 주석으로 처리합니다.

		/*
		 * 범위주석
		 */

		// "/*" 부터 "*/" 까지
	}
}
