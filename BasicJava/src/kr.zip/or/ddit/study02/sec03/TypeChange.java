package kr.or.ddit.study02.sec03;

public class TypeChange {
	public static void main(String[] args) {
		int a = 500;
		int b = 60;
		
		int min = a/b;
		int sec = a-min*b;
		System.out.println(min+"분 "+sec+"초");
	}

}
