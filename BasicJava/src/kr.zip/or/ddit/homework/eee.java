package kr.or.ddit.homework;

import java.util.Scanner;

public class eee {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		eee obj = new eee();
		obj.process();

	}

	public void process() {
		String str = sc.next();
		String str1 = "가위";
		String str2 = "바위";
		String str3 = "보";
		int a;
		if (str == str1) {
			a = 0;
		} else if (str == str2) {
			a = 1;
		} else {
			a = 2;
		}
	}
}
