package kr.or.ddit.homework;

import java.util.Scanner;

public class rrr {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		rrr obj = new rrr();
		obj.process();

	}
	public void process() {

	}
}
