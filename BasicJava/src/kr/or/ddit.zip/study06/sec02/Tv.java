package kr.or.ddit.study06.sec02;

public class Tv {
	String company;
	int size;
	
}
