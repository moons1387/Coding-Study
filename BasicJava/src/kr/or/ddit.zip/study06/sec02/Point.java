package kr.or.ddit.study06.sec02;

public class Point {
	int x;
	int y;
	int z;

	@Override
	public String toString() {
		return "(" + x + "." + y +"."+ z + ")";
	}

}
