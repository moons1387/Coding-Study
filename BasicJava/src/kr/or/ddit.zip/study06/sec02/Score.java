package kr.or.ddit.study06.sec02;

public class Score {
	int kor;
	int eng;
	int math;
	
	double avg;
}
