package kr.or.ddit.study06.sec06;

public class AccesDefault {
	int a;
	
	void defaultMethod1() {
		
	}
	void defaultMethod2() {
		
	}
}
