package kr.or.ddit.study06.sec06;

public class AccesPrivate {
	private int a;
	
	private void privateMethod1() {
		
	}
	private void privateMethod2() {
		
	}
}
