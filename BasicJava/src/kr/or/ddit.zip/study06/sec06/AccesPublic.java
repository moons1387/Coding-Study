package kr.or.ddit.study06.sec06;

public class AccesPublic {
	public int a;
	
	public void publicMethod() {
		
	}
}
