package kr.or.ddit.study06.sec03;

public class ScoreExample {
	public static void main(String[] args) {
		Score s1 = new Score(90, 90, 90);
		System.out.println(s1);
	}
}
