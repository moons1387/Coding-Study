package kr.or.ddit.study06.sec03;

public class Tv {
	String company;
	int size;
	
	public Tv() {
		
	}
	
	public Tv(String company, int size) {
		this.company = company;
		this.size = size;
	}
}
