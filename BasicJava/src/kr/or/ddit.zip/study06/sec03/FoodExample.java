package kr.or.ddit.study06.sec03;

public class FoodExample {
	public static void main(String[] args) {
		Food f1 = new Food(2022, "참치통조림", 3000);
		System.out.println(f1);
	}
}
