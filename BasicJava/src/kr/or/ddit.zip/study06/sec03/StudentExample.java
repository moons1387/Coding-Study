//package kr.or.ddit.study06.sec03;
//
//public class StudentExample {
//	public static void main(String[] args) {
//		Student s1 = new Student("정문성", 30);
////		System.out.println(s1);
////		
////		Student s2 = new Student("406호" ,"정문성", 30);
////		System.out.println(s2);
////		
////		Student s3 = new Student("미국", "406호", "노아", 20);
////		System.out.println(s3);
//	}
//}
