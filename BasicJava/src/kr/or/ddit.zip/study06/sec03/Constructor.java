package kr.or.ddit.study06.sec03;

public class Constructor {
	int a;
	int b;
	
	// 기본생성자
	public Constructor() {
	
	}
	
	public Constructor(int a, int b) {
		this.a = a;
		this.b = b;
		
	}
	
	
}
