//package kr.or.ddit.study06.sec03;
//
//public class Student {
//	String nation;
//	String roomNo;
//	String name;
//	int age;
//	
//	public Student(String name, int age) {
////		roomNo = "306호";
////		this.name = name;
////		this.age = age;
////		nation = "한국";
//		this("306", name, age);
//		System.out.println("파라미터 2개 짜리 생성자");
//	}
//	public Student(String roomNo, String name, int age) {
////		this.roomNo = roomNo;
////		this.name = name;
////		this.age = age;
////		nation = "한국";
//		this("한국", roomNo, name, age);
//		System.out.println("파라미터 3개 짜리 생성자"); 
//	}
//	public Student(String nation, String roomNo, String name, int age) {
//		this.roomNo = roomNo+"호";
//		this.name = name;
//		this.age = age;
//		this.nation = nation;
//		System.out.println("파라미터 4개 짜리 생성자");
//	}
//
//	@Override
//	public String toString() {
//		return "Student [nation=" + nation + ", roomNo=" + roomNo + ", name=" + name + ", age=" + age + "]";
//	}
//
//	
//	// Overloading	= 파라미터가 다를 경우 다른 파라미터를 호출한다.
//	// Override		= 기존의 기능을 덮어 씌워 작동시킨다.
//	
//	
//	
//	
//}
