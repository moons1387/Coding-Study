package kr.or.ddit.study06.sec01;

public class ClassExample {
	// 클래스 구성요소
	// 1. 필드
	int a;
	int b = 10;
	// 필드는 데이터를 담는 역할
	
	
	
	// 2. method
	
	// 메인 메소드
	public static void main(String[] args) {
		
	}
	
	// 테스트 메소드
	public void test() {
		
	}
	// 메소드는 동작을 하는 역할

	
	
	// 3. 생성자
	
	// 기본 생성자
	public ClassExample() {
		
	}
	
	// 생성자
	public ClassExample(int a, int b) {
		this.a = a;
		this.b = b;
	}
}
