package kr.or.ddit.study06.sec05;

public class StaticExample {
	int a = 10;
	static int b = 10;
	
	public void method1() {
		
	}
	public void method2() {
		
	}
	public static void method3() {
		
	}
	public static void method4() {
		
	}
}
