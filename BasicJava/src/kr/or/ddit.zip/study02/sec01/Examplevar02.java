package kr.or.ddit.study02.sec01;

public class Examplevar02 {
	public static void main(String[] args) {
		// 첫번째 글자는 문자이거나 $, _ 이어야 하고 숫자로 시작할 수 없다.
		int $var;
		int _var;
//	    int 1var; - X
	    int var;
	    
	    // 영어 대소문자를 구분합니다.
	    int exam;
	    int Exam;
	    int eXam;
	    
	    // 관례(카멜표기법)
	    int masSpeed;
	    int firstName;
	    
	    //길이 제한 없음
	    int aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa;
	    
	    //자바 예약어 사용 X
//	    int public; - X
	    int _public;
	    
	}

}
