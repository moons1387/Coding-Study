package kr.or.ddit.study02.sec01;

public class Examplevar01 {
	public static void main(String[] args) {

//		// 변수 선언
//		int x;
//		int y;
//		int z;
//		
//		// 변수 초기화
//		x = 1;
//		y = 2;
//		z = 3;
//		
//		System.out.println(x + ", " + y + ", " + z);
//
//		int x, y, z;
//		x = 1;
//		y = 2;
//		z = 3;
//
//		System.out.println(x + ", " + y + ", " + z);
		
		int x=1, y=2, z=3;
		System.out.println(x + ", " + y + ", " + z);
		
		
	}

}
