package kr.or.ddit.study02.sec04;

import java.util.Scanner;

public class Test0001 {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		Test0001 obj = new Test0001();
		obj.process();

	}

	public void process() {

	}
}
