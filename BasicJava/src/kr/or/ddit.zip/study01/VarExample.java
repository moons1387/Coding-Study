package kr.or.ddit.study01;

public class VarExample {
	public static void main(String[] args) {
		System.out.println("실행문 끝에는 반드시 세미콜론을 붙여야 합니다.")
		
		
		
		
		;
		System.out.println(";은 실행문이 끝났음을 표시 합니다.");
		
		int x=3;
		int y=6;
		int a = x+y;
		System.out.println(a);
	}
}
