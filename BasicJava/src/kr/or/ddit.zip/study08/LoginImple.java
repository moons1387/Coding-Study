package kr.or.ddit.study08;

public class LoginImple implements ILogin {

	@Override
	public boolean login(String id, String pass) {
		
		return false;
	}

	@Override
	public int sign(String id, String pass, String name, String tell) {

		return 0;
	}

}
