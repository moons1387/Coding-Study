package kr.or.ddit.study08;

public interface ILogin {

	public boolean login(String id, String pass);
	
	public int sign(String id, String pass, String name, String tell);
	
}
