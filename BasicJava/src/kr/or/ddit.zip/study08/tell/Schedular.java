package kr.or.ddit.study08.tell;

public interface Schedular{
	
	public void getNextCall();
	public void sendCallToAgent();
	
}
