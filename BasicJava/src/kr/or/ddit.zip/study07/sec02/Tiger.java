package kr.or.ddit.study07.sec02;

public class Tiger extends Animal{
	@Override
	public void cry() {
		System.out.println("어흥");
	}
}
