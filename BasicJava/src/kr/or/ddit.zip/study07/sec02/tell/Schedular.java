package kr.or.ddit.study07.sec02.tell;

public abstract class Schedular{
	
	abstract public void getNextCall();
	abstract public void sendCallToAgent();
}
