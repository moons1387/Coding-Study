package kr.or.ddit.study07.sec02;

public class Unit {
	
	int hp;
	
	public void move() {
		
	}

	public void attack() {

	}
}
