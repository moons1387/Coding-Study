package kr.or.ddit.study07.sec01;

public class BallPen extends Pen {

	private String color;

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

}
