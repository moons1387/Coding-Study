package kr.or.ddit.study07.sec01;

public class SmartPhone extends Phone {

	public void game() {
		System.out.println("게임 플레이");
	}

	public void internet() {
		System.out.println("인터넷 사용");
	}

	public void camera() {
		System.out.println("찰칵");
	}
}
