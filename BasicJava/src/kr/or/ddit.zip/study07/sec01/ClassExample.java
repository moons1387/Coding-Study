package kr.or.ddit.study07.sec01;

public class ClassExample {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
