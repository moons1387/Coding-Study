package kr.or.ddit.study07.sec01;

public class IPhone2 extends IPhone {
	@Override
	public void camera() {
		System.out.println("2000만 화소 카메라");

	}
}
