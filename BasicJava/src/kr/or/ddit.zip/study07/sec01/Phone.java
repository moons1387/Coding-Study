package kr.or.ddit.study07.sec01;

public class Phone {

	public void tell() {
		System.out.println("4g 전화걸기");
	}
}
