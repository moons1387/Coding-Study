package kr.or.ddit.study07.sec01;

public class DmbPhone extends Phone {
	public void dmb() {
		System.out.println("티비 시청");
	}
}
