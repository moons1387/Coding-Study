package kr.or.ddit.study07.sec01;

public class Pen {
	
	private int amount;

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
