package kr.or.ddit.ex;

import java.util.Scanner;

public class PPP {
	Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		PPP obj = new PPP();
		obj.process();

	}

	public void process() {
		method1();

	}
	public void method1() {
			int a =(int)(Math.random()*3+1);
			System.out.println(a);
		}
}
